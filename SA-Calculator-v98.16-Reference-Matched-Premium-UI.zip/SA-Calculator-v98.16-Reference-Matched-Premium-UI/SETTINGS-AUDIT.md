# SA Calculator v1.94.0-v94 — Settings audit

## Header / brand change
- Removed the decorative logo image from the in-app top header only.
- Basic Calculator header displays `SA Calculator`; every other screen displays its own screen title, translated where a translation exists.
- The navigation drawer retains the `SA Calculator` product brand independently of the active screen and language.
- App icon, favicon and install icon remain unchanged so Android/PWA identity is not accidentally lost.

## Complete settings inventory (12 groups)

1. **Appearance**
   - Fullscreen (this session): requests browser fullscreen; depends on WebView/browser support and user gesture.
   - Display Font Size: Compact, Standard (default), Comfortable Large.
   - Keep Screen Awake (this session): uses Screen Wake Lock where supported; released when session/app lifecycle ends or platform revokes it.
2. **Theme & Colors**
   - Accent Palette: opens the custom palette picker.
   - Appearance Mode: Light, Dark, Follow System.
   - Accent Highlight Color: seven supplied accent colors.
   - OLED Pure Black: toggles OLED black treatment.
3. **Calculator Settings**
   - Trigonometric Angle Unit: Degrees or Radians; shared with scientific calculator.
   - Instant Calculation Preview: enables/disables live preview.
   - Implicit Multiplication: controls implicit multiplication parsing.
4. **Decimal & Number Format**
   - Decimal Places: Auto, 0, 2, 4, 6.
   - Digit Grouping: comma, space, Indian lakh grouping, none.
   - Trailing Zeros: show/hide trailing zeros.
5. **Language**
   - Navigation Language: English, Hindi, Urdu, Spanish, French, German, Arabic, Chinese.
   - The v1.94.0 localization layer covers the 400-entry static UI/accessibility inventory, 628 shared keys, dynamic status messages, and selected-locale formatting. See `LOCALIZATION-AUDIT.md` for device/native-speaker validation gates.
6. **Startup Preferences**
   - Default Launch Screen: Calculator, Currency, Units, Discount, Percent, Sales Tax, Body Metrics, Date, Fuel Cost, Fuel Efficiency, Grade Average, Number Base, Loan/EMI, Savings, Tip, Unit Price, World Time, Resume Last Used Screen.
   - Restore Previous Values: stores/restores supported form inputs locally.
7. **Favorites Management**
   - Toggle calculator shortcuts in drawer Favorites.
   - Reset Favorites restores the default pinned set.
8. **History Settings**
   - Record Calculations toggle.
   - Maximum History Entries: 25, 50, 100, 500.
   - Clear History removes unlocked entries; protected/locked entries are retained.
9. **Clipboard & Copy**
   - Auto-Copy Results toggle.
10. **Sound & Vibration**
    - Keypad Touch Sound toggle.
    - Haptic Vibration toggle.
    - Vibration Intensity: Light 15ms, Medium 30ms, Strong 50ms (subject to OS/device support).
11. **Privacy**
    - Diagnostics is disabled; no telemetry upload control is exposed/enabled.
    - Local Offline Sandbox status.
    - Clear App Data & Cache removes local app state/cache; user should expect saved settings and local records to be lost.
12. **About & Support**
    - App version and independent-product status.
    - Help & User Guide opens a local help dialog.
    - Feedback & Bug Report opens a local draft; nothing is uploaded automatically; Copy/Share are user-initiated.
    - Reset All Settings restores preferences to defaults; it does not intentionally clear calculation history.

## Persistence and safety review
- Persisted preferences are loaded with type/range/allow-list validation before being applied.
- A normalized settings record is written only after restoration completes, avoiding partial overwrite during startup.
- Settings are stored locally in browser/WebView storage; storage availability is platform-dependent.
- Fullscreen and wake lock are session-only platform capabilities, not durable preferences.
- Telemetry remains forced off regardless of stored values.
- The Basic Calculator title remains `SA Calculator`; other screen titles follow the active screen and available language translation.

## Verification limits
- Automated regression suite: 58/58 automated regression tests passed for the preceding v90.1 release; v91 full suite: 59 passed, 0 failed, 0 skipped; see `RELEASE-VERIFICATION.md`.
- Browser/WebView capability differences (fullscreen, wake lock, vibration, share sheet) still require hands-on checks on target Android devices.
- No claim is made that every Android model or OS version has been physically tested.


## v1.92.7-v92 language update

- Language selection now applies the shared localization layer across matching static and dynamic UI text, select options, accessibility labels and placeholders.
- Urdu and Arabic set RTL document direction while keeping calculator expression and currency amount entry LTR.
- Numeric-only UI text, keypad glyphs and committed calculator results use locale digits; keypad action values remain ASCII.
- This is not yet 100% translation coverage; unmatched phrases remain English.


## v1.94.0 localization corrections

Input placeholders and accessible labels now localize; dynamic text mutations are tracked safely; selected-language currency labels are refreshed when the language changes. The phrase catalogue contains 154 entries, but unmatched strings still fall back to English.


## v1.98.4-v98.4 settings cleanup

- The 15-option Accent Palette picker is the only visible accent selector; the older 7-option Accent Highlight Color selector was a duplicate and has been removed. A hidden compatibility field remains so saved accent preferences and existing initialization code continue to work.
- Removed the disabled Diagnostics switch: diagnostics/telemetry is forced off and no upload endpoint exists, so the switch was non-functional. Privacy disclosure and the explicit clear-data action remain.
- Removed the non-functional Project Status row. Help, feedback, reset settings and all data-management actions remain.
- All 12 settings groups and all meaningful preferences remain intact.
