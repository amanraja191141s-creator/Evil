# SA Calculator v98.16 — reference-matched premium neon UI

## Visual target
The supplied 16 November 2026 screenshot is the visual reference. The implementation adopts its midnight/black and deep-navy base, electric-blue/cyan illuminated borders, metallic SA brand mark, white-to-ice-blue input surfaces, vivid green result panels, blue gradient action buttons, and restrained gold highlights.

## Screen coverage
All 18 existing destinations remain registered and functional: Calculator, Currency Converter, Unit Converter, Discount Calculator, Percent Calculator, Sales Tax, Body Metrics, Date Calculator, Fuel Cost, Fuel Efficiency, Grade Average, Number Base, Loan/EMI, Savings, Tip Calculator, Unit Price, World Time, and Settings. The 17 non-calculator screens receive compact screen title bars; each remains a full-size interactive screen rather than being shrunk into the promotional contact-sheet layout shown in the reference.

## Shared components
The release refreshes the app header/brand lockup, input and select controls, cards, result panels, primary actions, calculator keypad, dock keypads, currency pair panels, settings rows, drawer, history, scientific panel, currency picker, toast and focus states. Responsive rules cover narrow phones, larger phones/tablets, landscape, reduced motion and forced-colour accessibility.

## Behaviour preservation
This is a visual-layer update. Existing element IDs, data attributes, calculator expressions, currency rate handling, tool formulas, navigation routes, event listeners, storage keys, and Android/Capacitor build flow are retained. No claim is made that an Android APK was built or device-tested in this environment.

## Release
- Version: `1.98.16-v98.16`
- Service-worker cache: `sa-calculator-v98-16-reference-premium-ui`
- Source of truth: `assets/css/app.css`, final v98.16 layer
