'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '..', 'assets/js/app.js'), 'utf8');
function extract(name) {
  const start = source.indexOf(`function ${name}(`);
  assert.notEqual(start, -1, `${name} missing`);
  const open = source.indexOf('{', start);
  let depth = 0, quote = '', template = false, line = false, block = false;
  for (let i = open; i < source.length; i++) {
    const ch = source[i], next = source[i + 1];
    if (line) { if (ch === '\n') line = false; continue; }
    if (block) { if (ch === '*' && next === '/') { block = false; i++; } continue; }
    if (quote) { if (ch === '\\') { i++; continue; } if (ch === quote) quote = ''; continue; }
    if (ch === '/' && next === '/') { line = true; i++; continue; }
    if (ch === '/' && next === '*') { block = true; i++; continue; }
    if (ch === "'" || ch === '"' || ch === '`') { quote = ch; continue; }
    if (ch === '{') depth++;
    else if (ch === '}' && --depth === 0) return source.slice(start, i + 1);
  }
  throw new Error(`Could not extract ${name}`);
}
function setup(saved = null) {
  const listeners = new Map();
  const buttons = ['MC','MR','M+','M-','MS'].map(action => ({
    getAttribute: key => key === 'data-memory' ? action : null,
    addEventListener: (event, fn) => listeners.set(action, fn)
  }));
  const store = new Map(saved ? [['sumaire_memory_v1', JSON.stringify(saved)]] : []);
  const indicator = { textContent: '', attrs: {}, setAttribute(k,v){this.attrs[k]=v;} };
  const context = {
    STATE: { memoryValue:0, memoryHasValue:false, isResultMode:false, calcVal:'0', calcRawValue:null,
      calcExpr:'', calcScientificContinuation:{old:true}, calcScientificErrorPreview:true,
      calcScientificErrorExpression:'old', calcRepeat:{old:true}, calcResultExpression:'old',
      calcErrorMessage:'', calcCursor:0, calcSelectionStart:0, calcSelectionEnd:0 },
    localStorage: { getItem:k=>store.get(k) ?? null, setItem:(k,v)=>store.set(k,v), removeItem:k=>store.delete(k) },
    document: { querySelectorAll:()=>buttons, getElementById:id=>id==='memory-indicator'?indicator:null },
    showToast: msg=>{context.toast=msg;}, triggerHaptic(){},
    normalizedCalcExpression: x => String(x).replace(/([0-9.]+)×10([⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻]+)/g, (_m, mantissa, exp) => {
      const digits = {'⁰':'0','¹':'1','²':'2','³':'3','⁴':'4','⁵':'5','⁶':'6','⁷':'7','⁸':'8','⁹':'9','⁺':'+','⁻':'-'};
      return `${mantissa}e${exp.split('').map(ch => digits[ch] ?? ch).join('')}`;
    }),
    evaluateArithmetic: x=>{const n=Number(x); if(!Number.isFinite(n)) throw Error('bad'); return n;},
    parseDisplayedCalculatorValue: Number,
    formatCalculatorResultNumber: value => {
      const n = Number(value);
      if (!Number.isFinite(n)) return 'Error';
      const abs = Math.abs(n);
      if (abs >= 1e12 || (abs > 0 && abs < 1e-6)) {
        const [mantissa, exponent] = n.toExponential(6).split('e');
        const superscript = String(Number(exponent)).replace(/-/g, '⁻').replace(/\d/g, d => '⁰¹²³⁴⁵⁶⁷⁸⁹'[Number(d)]);
        return `${mantissa.replace(/(\.\d*?)0+$/, '$1').replace(/\.$/, '')}×10${superscript}`;
      }
      return String(n);
    },
    updateCalcDisplayDOM(){context.displayUpdated=true;},
    setCalcEditorSelection(){context.selectionUpdated=true;},
    Number, String, JSON, Math
  };
  const names=['restoreCalculatorMemory','persistCalculatorMemory','updateMemoryIndicator','currentCalculatorNumericValue','initMemoryControls'];
  vm.runInNewContext(names.map(extract).join('\n')+';globalThis.init=initMemoryControls;', context);
  context.init();
  return {context, listeners, store, indicator, press: action=>listeners.get(action)()};
}
test('MC, MR, MS, M+ and M- perform their distinct standard memory operations', () => {
  const x=setup();
  x.context.STATE.calcExpr='12'; x.press('MS');
  assert.equal(x.context.STATE.memoryValue,12); assert.equal(x.context.STATE.memoryHasValue,true);
  x.context.STATE.calcExpr='5'; x.press('M+'); assert.equal(x.context.STATE.memoryValue,17);
  x.context.STATE.calcExpr='3'; x.press('M-'); assert.equal(x.context.STATE.memoryValue,14);
  x.context.STATE.calcExpr='99'; x.press('MR');
  assert.equal(x.context.STATE.calcExpr,'14'); assert.equal(x.context.STATE.memoryValue,14);
  assert.equal(x.context.STATE.calcScientificContinuation,null); assert.equal(x.context.STATE.calcRepeat,null);
  x.press('MR'); assert.equal(x.context.STATE.memoryValue,14,'recall must not clear memory');
  x.press('MC'); assert.equal(x.context.STATE.memoryHasValue,false); assert.equal(x.context.STATE.memoryValue,0);
  assert.equal(x.store.has('sumaire_memory_v1'),false); assert.equal(x.indicator.textContent,'');
});
test('memory survives reinitialization and corrupt stored values are ignored safely', () => {
  const first=setup(); first.context.STATE.calcExpr='123.5'; first.press('MS');
  const second=setup(JSON.parse(first.store.get('sumaire_memory_v1')));
  assert.equal(second.context.STATE.memoryValue,123.5); assert.equal(second.indicator.textContent,'M');
  const corrupt=setup({value:'Infinity',hasValue:true});
  assert.equal(corrupt.context.STATE.memoryHasValue,false);
});
test('memory rejects invalid current results without corrupting previous memory', () => {
  const x=setup({value:7,hasValue:true});
  x.context.STATE.calcExpr='not-a-number'; x.press('M+');
  assert.equal(x.context.STATE.memoryValue,7); assert.equal(x.context.STATE.memoryHasValue,true);
  assert.match(x.context.toast,/valid calculation/i);
});

test('MS then MR preserves six-digit scientific display and exact numeric continuation value', () => {
  const x = setup();
  const exact = 1234567890123.456;
  x.context.STATE.isResultMode = true;
  x.context.STATE.calcVal = '1.234568×10¹²';
  x.context.STATE.calcRawValue = exact;
  x.press('MS');
  assert.equal(x.context.STATE.memoryValue, exact);
  x.context.STATE.calcExpr = '999';
  x.press('MR');
  assert.equal(x.context.STATE.calcExpr, '1.234568×10¹²');
  assert.equal(x.context.STATE.calcVal, '1.234568×10¹²');
  assert.equal(x.context.STATE.calcRawValue, exact);
  assert.deepEqual(JSON.parse(JSON.stringify(x.context.STATE.calcScientificContinuation)), {
    displayToken: '1.234568×10¹²', exactValue: exact
  });
  assert.equal(x.context.STATE.memoryValue, exact, 'MR must not clear or alter memory');
  assert.equal(x.context.displayUpdated, true);
});

test('MS then MR keeps e11-range values ordinary and e12-range values scientific', () => {
  const ordinary = setup();
  ordinary.context.STATE.calcExpr = '100000000000';
  ordinary.press('MS');
  ordinary.press('MR');
  assert.equal(ordinary.context.STATE.calcExpr, '100000000000');
  assert.equal(ordinary.context.STATE.calcScientificContinuation, null);

  const scientific = setup();
  scientific.context.STATE.calcExpr = '1000000000000';
  scientific.press('MS');
  scientific.press('MR');
  assert.equal(scientific.context.STATE.calcExpr, '1×10¹²');
  assert.equal(scientific.context.STATE.calcScientificContinuation.displayToken, '1×10¹²');
  assert.equal(scientific.context.STATE.calcRawValue, 1e12);
});
